"use strict";
exports.id = 859;
exports.ids = [859];
exports.modules = {

/***/ 859:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ HomeTwo_Pricing)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/components/common/SinglePrice.jsx


const SinglePrice = ({ title , num1 , num2 , num3 , num4 , price , active  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "col-xl-4 col-lg-6 col-md-6",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `${active ? "pricing__item pricing__item-active text-center mb-30" : "pricing__item text-center mb-30"}`,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "pricing__item-name mb-5",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                children: title
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Worth added administrations guarantee the progression study"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "pricing__item-info mb-50",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                children: "Monthly Made"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "pnumber",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "#",
                                        children: num1
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "#",
                                        children: num2
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "#",
                                        children: num3
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "#",
                                        children: num4
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "pricing__item-price mb-30",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                children: [
                                    "$",
                                    price
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Anytime package cancellation process"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "pricing__item-button",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/pricing",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                className: `${active ? "tp-btn-df-active" : "tp-btn-df"}`,
                                children: [
                                    "Purchase Now ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fal fa-long-arrow-right"
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const common_SinglePrice = (SinglePrice);

;// CONCATENATED MODULE: ./src/components/HomeTwo/Pricing.jsx


const Pricing = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "pricing__area-2 grey-bg-8 pt-110 pb-130 pricing__overlay",
            style: {
                background: `url(assets/img/bg/price-bg-1.jpg)`,
                backgroundRepeat: "no-repeat",
                backgroundPosition: "center",
                backgroundSize: "cover"
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row align-items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-6 col-lg-6 col-md-7",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "section-2__wrapper mb-55",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "st-1",
                                            children: "Price & Plans"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "section__title-sd",
                                            children: "Service Planing"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-6 col-lg-6 col-md-5",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "pricing__tabs",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "nav nav-tabs",
                                        id: "priceTab",
                                        role: "tablist",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item",
                                                role: "presentation",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "nav-link active",
                                                    id: "monthly-tab",
                                                    "data-bs-toggle": "tab",
                                                    "data-bs-target": "#monthly",
                                                    type: "button",
                                                    role: "tab",
                                                    "aria-controls": "monthly",
                                                    "aria-selected": "true",
                                                    children: "Annual Plan"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item",
                                                role: "presentation",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "nav-link",
                                                    id: "yearly-tab",
                                                    "data-bs-toggle": "tab",
                                                    "data-bs-target": "#yearly",
                                                    type: "button",
                                                    role: "tab",
                                                    "aria-controls": "yearly",
                                                    "aria-selected": "false",
                                                    children: "Monthly Plan"
                                                })
                                            })
                                        ]
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "tab-content",
                        id: "priceTabContent",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "tab-pane fade active show",
                                id: "monthly",
                                role: "tabpanel",
                                "aria-labelledby": "monthly-tab",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "row",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(common_SinglePrice, {
                                            title: "Basic Plan",
                                            num1: "01",
                                            num2: "02",
                                            num3: "05",
                                            num4: "10+",
                                            price: 49.0
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(common_SinglePrice, {
                                            title: "Team Plan",
                                            num1: "01",
                                            num2: "02",
                                            num3: "05",
                                            num4: "10+",
                                            price: 99.0,
                                            active: true
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(common_SinglePrice, {
                                            title: "Advanced Plan",
                                            num1: "10",
                                            num2: "20",
                                            num3: "50",
                                            num4: "100+",
                                            price: 120.0
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "tab-pane fade",
                                id: "yearly",
                                role: "tabpanel",
                                "aria-labelledby": "yearly-tab",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "row",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(common_SinglePrice, {
                                            title: "Standard Plan",
                                            num1: "01",
                                            num2: "02",
                                            num3: "05",
                                            num4: "10+",
                                            price: 50.0
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(common_SinglePrice, {
                                            title: "Premium Plan",
                                            num1: "01",
                                            num2: "02",
                                            num3: "05",
                                            num4: "10+",
                                            price: 100.0,
                                            active: true
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(common_SinglePrice, {
                                            title: "Platinum Plan",
                                            num1: "10",
                                            num2: "20",
                                            num3: "50",
                                            num4: "100+",
                                            price: 150.0
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const HomeTwo_Pricing = (Pricing);


/***/ })

};
;