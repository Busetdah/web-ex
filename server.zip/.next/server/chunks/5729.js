"use strict";
exports.id = 5729;
exports.ids = [5729];
exports.modules = {

/***/ 5729:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const blogData = [
    {
        id: 1,
        img: "assets/img/blog/Feedmill3.jpeg",
        imgBig: "assets/img/blog/blog-d-1.jpg",
        imgTwo: "assets/img/blog/Feedmill3.jpeg",
        date: "Feb 23, 2022",
        title: "Steel Structure",
        titleTwo: "Both the act of teaching knowledge to others and the act of kind.",
        author: "IQBAL",
        authorThree: "Feedmill"
    },
    {
        id: 2,
        img: "assets/img/blog/blog-sm-2.jpg",
        imgBig: "assets/img/blog/blog-d-2.jpg",
        imgTwo: "assets/img/blog/deltaeng2.jpeg",
        date: "Feb 26, 2022",
        title: "Installation Silo",
        titleTwo: "How To Build And Launch Powerful Responsive Websites With Editor.",
        author: "MAXSON",
        authorThree: "Silo",
        video: true
    },
    {
        id: 3,
        img: "assets/img/blog/blog-sm-3.jpg",
        imgBig: "assets/img/blog/blog-d-3.jpg",
        imgTwo: "assets/img/blog/roboting.jpg",
        date: "Feb 28, 2022",
        title: "Installation Robotic Palletizing",
        titleTwo: "New items are released weekly. Check out some of our newest.",
        author: "CHOPPER",
        authorThree: "Palletizing",
        slider: true
    },
    {
        id: 4,
        img: "assets/img/blog/blog-sm-3.jpg",
        imgBig: "assets/img/blog/blog-d-3.jpg",
        imgTwo: "assets/img/blog/flat2.jpeg",
        date: "Feb 28, 2022",
        title: "Flat Storage Warehouse Installation",
        titleTwo: "New items are released weekly. Check out some of our newest.",
        author: "CHOPPER",
        authorThree: "Flat Storage",
        slider: true
    },
    {
        id: 5,
        img: "assets/img/blog/blog-sm-3.jpg",
        imgBig: "assets/img/blog/blog-d-3.jpg",
        imgTwo: "assets/img/blog/plc1.jpeg",
        date: "Feb 28, 2022",
        title: "Automation Installation",
        titleTwo: "New items are released weekly. Check out some of our newest.",
        author: "CHOPPER",
        authorThree: "PLC",
        slider: true
    },
    {
        id: 6,
        img: "assets/img/blog/blog-sm-3.jpg",
        imgBig: "assets/img/blog/blog-d-3.jpg",
        imgTwo: "assets/img/blog/blog-3.jpg",
        date: "Feb 28, 2022",
        title: "By any person who has access to the internet",
        titleTwo: "New items are released weekly. Check out some of our newest.",
        author: "CHOPPER",
        authorThree: "Sanji Max",
        slider: true
    },
    {
        id: 7,
        img: "assets/img/blog/blog-sm-3.jpg",
        imgBig: "assets/img/blog/blog-d-3.jpg",
        imgTwo: "assets/img/blog/blog-3.jpg",
        date: "Feb 28, 2022",
        title: "By any person who has access to the internet",
        titleTwo: "New items are released weekly. Check out some of our newest.",
        author: "CHOPPER",
        authorThree: "Sanji Max",
        slider: true
    },
    {
        id: 8,
        img: "assets/img/blog/blog-sm-4.jpg",
        imgBig: "assets/img/blog/blog-d-4.jpg",
        date: "Feb 20, 2022",
        title: "Their experience to any review site or"
    }, 
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (blogData);


/***/ })

};
;