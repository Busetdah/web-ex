import SingleCompanyAbout from "../common/SingleCompanyAbout";

const CompanyAbout = () => {
  return (
    <>
  
    </>
  );
};

export default CompanyAbout;
