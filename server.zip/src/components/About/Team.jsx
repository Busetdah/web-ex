import Link from 'next/link';

const Team = () => {
  const teamData = [
    {
      id: 1,
      img: "assets/img/team/3/team-1.jpg",
      name: "Rosalina D. William",
    },
    {
      id: 2,
      img: "assets/img/team/3/team-2.jpg",
      name: "Dr. Benjamin",
    },
    {
      id: 3,
      img: "assets/img/team/3/team-3.jpg",
      name: "Josep Max",
    },
    {
      id: 4,
      img: "assets/img/team/3/team-4.jpg",
      name: "Iqbal Hossain",
    },
  ];
  return (
    <>
  
    </>
  );
};

export default Team;
