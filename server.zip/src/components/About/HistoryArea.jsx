import Link from 'next/link';

const HistoryArea = () => { 
  const historyData = [
    {
      id: 1,
      img: "assets/img/testimonial/testimonial-1.jpg",
      year: 2000,
      title: "Journey was started",
    },
    {
      id: 2,
      img: "assets/img/testimonial/testimonial-2.jpg",
      year: 2008,
      title: "Best agency in new york",
    },
    {
      id: 3,
      img: "assets/img/testimonial/testimonial-3.jpg",
      year: 2015,
      title: "Best design award in",
    },
    {
      id: 4,
      img: "assets/img/testimonial/testimonial-4.jpg",
      year: 2022,
      title: "Category design awards",
    },
  ];
  return ( 
    <>
     
    </>
  );
};

export default HistoryArea;
