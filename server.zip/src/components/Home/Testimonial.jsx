import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Autoplay } from "swiper";

const Testimonial = () => {
  const testimonialData = [
    {
      id: 1,
      desc: "“ A user review is a review conducted by any person who has access to the internet and publishes their ux to a review site or social media platform ”",
      author: "assets/img/author/client-1.jpg",
      name: "Alonso Dowson",
      title: (
        <>
          <p>
            Head Of Idea , <a href="#">Alonso Co.</a>
          </p>
        </>
      ),
    },
    {
      id: 2,
      desc: "“ A user review is a review conducted by any person who has access to the internet and publishes their ux to a review site or social media platform ”",
      author: "assets/img/author/client-2.jpg",
      name: "Rosalina William",
      title: (
        <>
          <p>
            CEO , <a href="#">Rosa Corporation</a>
          </p>
        </>
      ),
    },
    {
      id: 3,
      desc: "“ Design quality superlative account on its cloud platform. Think Dikons is the best theme I ever seen this year. Amazing design, easy to customize a ”",
      author: "assets/img/author/client-3.jpg",
      name: "Iqbal Hossain",
      title: (
        <>
          <p>
            Founder , <a href="#">Gazi Company</a>
          </p>
        </>
      ),
    },
    {
      id: 4,
      desc: "“ Amazing design, easy to customize a design quality superlative account on its cloud platform. Think Dikons is the best theme I ever seen this year. ”",
      author: "assets/img/author/client-4.jpg",
      name: "Josep D. William",
      title: (
        <>
          <p>
            Head Of Idea , <a href="#">William Co.</a>
          </p>
        </>
      ),
    },
  ];
  return (
    <>
  
    </>
  );
};

export default Testimonial;
