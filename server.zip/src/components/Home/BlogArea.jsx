import Link from "next/link";
import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Autoplay } from "swiper";
import blogData from "../../data/blogData";

const BlogArea = () => {
  return (
    <>
  
    </>
  );
};

export default BlogArea;
