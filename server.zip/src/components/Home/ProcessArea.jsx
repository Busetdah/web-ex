import Link from 'next/link';

const ProcessArea = () => {
  return (
    <>
 
    </>
  );
};

export default ProcessArea;
