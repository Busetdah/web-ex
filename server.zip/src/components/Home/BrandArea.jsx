import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Autoplay } from "swiper";

const BrandArea = () => {
  const brandImg = [
    {
      id: 1,
      img: "assets/img/brand/brand-1.png",
    },
    {
      id: 2,
      img: "assets/img/brand/brand-2.png",
    },
    {
      id: 3,
      img: "assets/img/brand/brand-3.png",
    },
    {
      id: 4,
      img: "assets/img/brand/brand-4.png",
    },
    {
      id: 5,
      img: "assets/img/brand/brand-5.png",
    },
    {
      id: 6,
      img: "assets/img/brand/brand-1.png",
    },
  ];
  return (
    <>
   
    </>
  );
};

export default BrandArea;
