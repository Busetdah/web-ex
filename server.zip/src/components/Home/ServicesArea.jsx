import { Swiper, SwiperSlide } from "swiper/react";
import Link from 'next/link';
import SwiperCore, { Navigation, Autoplay } from "swiper";

const ServicesArea = () => {
  return (
    <>

    </>
  );
};

export default ServicesArea;
