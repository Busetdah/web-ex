import { Swiper, SwiperSlide } from "swiper/react";
import Link from 'next/link';
import SwiperCore, { Autoplay } from "swiper";

const TeamArea = () => {
  const teamData = [
    {
      id: 1,
      img: "assets/img/team/team-5.jpg",
      title: "Head Of Idea",
      name: "Alonso D. Dowson",
    },
    {
      id: 2,
      img: "assets/img/team/team-4.jpg",
      title: "Ceo Of Cmt",
      name: "Angliya Willam",
    },
    {
      id: 3,
      img: "assets/img/team/team-2.jpg",
      title: "Head Of Instractor",
      name: "Josep D. Maxson",
    },
    {
      id: 4,
      img: "assets/img/team/team-3.jpg",
      title: "Head Of Art",
      name: "Iqbal Hossain",
    },
    {
      id: 5,
      img: "assets/img/team/team-1.jpg",
      title: "Head Of Art",
      name: "Sanji Maxspn",
    },
    {
      id: 6,
      img: "assets/img/team/team-6.jpg",
      title: "Head Of Creative",
      name: "Andrew Woon",
    },
  ];
  return (
    <>
   
    </>
  );
};

export default TeamArea;
