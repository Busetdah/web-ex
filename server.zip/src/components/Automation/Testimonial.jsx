import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Autoplay } from "swiper";

const Testimonial = () => {
  const testimonialData = [
    {
      id: 1,
      authorImg: "assets/img/author/author-7.jpg",
      desc: "“ The completely synergize resource taxing relationships via premier niche markets. Professionally cultivate one-to-one customer service with robust ideas.”",
      name: "Miranda H. Halim",
    },
    {
      id: 2,
      authorImg: "assets/img/author/author-6.jpg",
      desc: "“ Professionally cultivate one-to-one customer service with robust ideas. The completely synergize resource taxing relati in the patnership uou join via premier niche markets.”",
      name: "Iqbal Hossain",
    },
    {
      id: 3,
      authorImg: "assets/img/author/author-5.jpg",
      desc: "“ The completely synergize resource taxing relationships via premier niche markets. Professionally cultivate one-to-one customer service with robust ideas.”",
      name: "Nico Robin",
    },
  ];
  return (
    <>
    
    </>
  );
};

export default Testimonial;
