import Link from "next/link";

const SmServices = () => {
  const smServicesData = [
    {
      id: 1,
      icon: "flaticon-container-1",
    },
    {
      id: 2,
      icon: "flaticon-lever",
    },
    {
      id: 3,
      icon: "flaticon-pumpjack",
    },
    {
      id: 4,
      icon: "flaticon-conveyor-belt",
    },
  ];
  return (
    <>
   
    </>
  );
};

export default SmServices;
