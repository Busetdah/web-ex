import Link from 'next/link';

const SmNavigation = () => {
  return (
    <>

    </>
  );
};

export default SmNavigation;
