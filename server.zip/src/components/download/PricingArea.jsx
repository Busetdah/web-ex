import SinglePricingThree from "../common/SinglePricingThree";

const PricingArea = () => {
  return (
    <>
 
    </>
  );
};

export default PricingArea;
