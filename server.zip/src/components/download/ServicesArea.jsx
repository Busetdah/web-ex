import Link from "next/link";

const ServicesArea = () => {
  const servicesData = [
    {
      id: 1,
      icon: "flaticon-ai",
      title: "Industrial Manufacturing",
    },
    {
      id: 2,
      icon: "flaticon-warehouse",
      title: (
        <>
          Engineering <br /> Solutions
        </>
      ),
    },
    {
      id: 3,
      icon: "flaticon-crusher",
      title: (
        <>
          Building <br /> Maintenance
        </>
      ),
    },
    {
      id: 4,
      icon: "flaticon-factory",
      title: (
        <>
          Lead Abatement <br /> &amp; Asbestos
        </>
      ),
    },
    {
      id: 5,
      icon: "flaticon-lever",
      title: (
        <>
          Tertiary Sector of <br /> Industry
        </>
      ),
    },
    {
      id: 6,
      icon: "flaticon-chip",
      title: (
        <>
          Include Health <br /> Care
        </>
      ),
    },
    {
      id: 7,
      icon: "flaticon-stock",
      title: (
        <>
          Warehouse <br /> & Reservation
        </>
      ),
    },
    {
      id: 8,
      icon: "flaticon-tank-truck",
      title: (
        <>
          Well as Final <br /> Consumer
        </>
      ),
    },
  ];
  return (
    <>

    </>
  );
};

export default ServicesArea;
