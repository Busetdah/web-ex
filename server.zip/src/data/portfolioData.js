const portfolioData = [
    {
        id:1,
        img:'assets/img/portfolio/protfolio-1.jpg',
        title:'That are related based on their primary business',
        category:'Manufacturing'
    },
    {
        id:2,
        img:'assets/img/portfolio/protfolio-1.jpg',
        title:'That are related based on their primary business',
        category:'MaterialsMaking'
    },
    {
        id:3,
        img:'assets/img/portfolio/protfolio-2.jpg',
        title:'An industry is a group of companies',
        category:'Industry'
    },
    {
        id:4,
        img:'assets/img/portfolio/protfolio-2.jpg',
        title:'An industry is a group of companies',
        category:'RennovaTion'
    },
    {
        id:5,
        img:'assets/img/portfolio/protfolio-3.jpg',
        title:'That while an automobile manufacturer',
        category:'Manufacturing'
    },
    {
        id:6,
        img:'assets/img/portfolio/protfolio-3.jpg',
        title:'That while an automobile manufacturer',
        category:'MaterialsMaking'
    },
    {
        id:7,
        img:'assets/img/portfolio/protfolio-4.jpg',
        title:'Have a financing division that contributes',
        category:'Manufacturing'
    },
    {
        id:8,
        img:'assets/img/portfolio/protfolio-4.jpg',
        title:'Have a financing division that contributes',
        category:'MaterialsMaking'
    },
    {
        id:9,
        img:'assets/img/portfolio/protfolio-6.jpg',
        title:"The firm's overall revenues, the company",
        category:'Industry'
    },
    {
        id:10,
        img:'assets/img/portfolio/protfolio-6.jpg',
        title:"The firm's overall revenues, the company",
        category:'RennovaTion'
    },
    {
        id:11,
        img:'assets/img/portfolio/protfolio-7.jpg',
        title:"Would be classified in the automaker industry",
        category:'RennovaTion'
    },
    {
        id:12,
        img:'assets/img/portfolio/protfolio-7.jpg',
        title:"Would be classified in the automaker industry",
        category:'Manufacturing'
    },
    {
        id:13,
        img:'assets/img/portfolio/protfolio-8.jpg',
        title:"Content creation company specializes in designing",
        category:'Manufacturing'
    },
    {
        id:14,
        img:'assets/img/portfolio/protfolio-8.jpg',
        title:"Content creation company specializes in designing",
        category:'MaterialsMaking'
    },
    {
        id:15,
        img:'assets/img/portfolio/protfolio-9.jpg',
        title:"Producing content in all its forms, audio, video",
        category:'Industry'
    },
    {
        id:15,
        img:'assets/img/portfolio/protfolio-9.jpg',
        title:"Producing content in all its forms, audio, video",
        category:'RennovaTion'
    },
    {
        id:16,
        img:'assets/img/portfolio/protfolio-10.jpg',
        title:"Distributes it through anymedium or channel.",
        category:'Manufacturing'
    },
    {
        id:17,
        img:'assets/img/portfolio/protfolio-10.jpg',
        title:"Distributes it through anymedium or channel.",
        category:'MaterialsMaking'
    },
    {
        id:18,
        img:'assets/img/portfolio/protfolio-11.jpg',
        title:"Creation companies know the basics of content",
        category:'Manufacturing'
    },
    {
        id:19,
        img:'assets/img/portfolio/protfolio-11.jpg',
        title:"Creation companies know the basics of content",
        category:'MaterialsMaking'
    },
    {
        id:20,
        img:'assets/img/portfolio/protfolio-12.jpg',
        title:"Marketing & generate ideas that resonate",
        category:'Industry'
    },
    {
        id:21,
        img:'assets/img/portfolio/protfolio-12.jpg',
        title:"Marketing & generate ideas that resonate",
        category:'RennovaTion'
    },
    {
        id:22,
        img:'assets/img/portfolio/protfolio-5.jpg',
        title:"Are four types of industry. These are primary",
        category:'RennovaTion'
    },
    {
        id:23,
        img:'assets/img/portfolio/protfolio-5.jpg',
        title:"Are four types of industry. These are primary",
        category:'Manufacturing'
    },
]

export default portfolioData;